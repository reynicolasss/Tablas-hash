package co.edu.upb.hash;

public class Hash {

    private final Integer tamaño = 8;
    private String[] arreglo;

    public Hash() {
        arreglo = new String[tamaño];
        for (int i = 0; i < tamaño; i++) {
            arreglo[i] = "-1";
        }
    }

    public int buscar(String valor) {
    	int indice = Integer.parseInt(valor) % (tamaño - 1);
        int contador = 0;

        while (!arreglo[indice].equals("-1")) {
            if (arreglo[indice].equals(valor)) {
                System.out.println("El valor " + valor + " se encontro en el índice " + indice);
                return indice;
            }

            indice++;
            indice %= tamaño;
            contador++;

            if (contador > tamaño) {
                break;
            }
        }
        System.out.println("El valor " + valor + " no esta");
        return -1;
    }

    public void insertar(String valor) {
    	int indice = Integer.parseInt(valor) % (tamaño - 1);

        while (!arreglo[indice].equals("-1")) {
            indice++;
            indice %= tamaño;
        }

        arreglo[indice] = valor;
        System.out.println(valor + "   tiene el hash --->  " + indice);
    }

    public void borrar(String valor) {
        int indice = buscar(valor);

        if (indice != -1) {
            arreglo[indice] = "-1";
            System.out.println("Se borro el valor " + valor + " en el índice " + indice);
        }
    }
}
