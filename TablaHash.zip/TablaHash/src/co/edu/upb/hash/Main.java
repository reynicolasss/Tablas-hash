package co.edu.upb.hash;

public class Main {

    public static void main(String[] args) {
        Hash Hash = new Hash();

        Hash.insertar("45");
        Hash.insertar("70");
        Hash.insertar("12");
        Hash.insertar("32");
        Hash.insertar("98");
        Hash.insertar("31");
        Hash.insertar("21");
        Hash.insertar("53");


        System.out.println(Hash.buscar("98"));

        Hash.borrar("32");
    }
}