package co.edu.upb.estrcuturaHash;

public class Main {

	public static void main(String[] args) {
		
		Hash hash = new Hash (8);
		
		String[] valores = { "23", "14", "10", "19", "40", "32", "18", "39"};
		
		 // Funcion cuadrática
		
		System.out.println("Ejemplo funcion cuadratica: ");
		System.out.println();

	    hash.funcionHash(valores, hash.arreglo, true);
	    hash.mostrarTabla();

	    // Busca un valor
	    String valorBuscado = hash.buscar("14");

	    if (valorBuscado == null) {
	        System.out.println("El elemento no está en la tabla");
	    }
	    hash.limpiarTabla();
	    
	 // Funcion lineal
	    System.out.println("------------------------------------");
		System.out.println("Ejemplo funcion lineal: ");
		System.out.println();

		
	    hash.funcionHash(valores, hash.arreglo, false);
	    hash.mostrarTabla();

	    String valorBuscado1 = hash.buscar("14");

	    if (valorBuscado1 == null) {
	        System.out.println("El elemento no está en la tabla");
	    }
	    hash.limpiarTabla();
	}
}
