package co.edu.upb.estrcuturaHash;

import java.util.Arrays;

public class Hash {

	String [] arreglo;
	int tamano;
	int contador = 0;
	
	public Hash (int tam) {
		tamano = tam;
		arreglo = new String [tam];
		Arrays.fill(arreglo, "-1");
	}
	
	public void funcionHash (String [] cadenaArreglo, String [] arreglo, boolean Cuadratico) {
		int i;
		for(i=0; i< cadenaArreglo.length; i++) {
			
			String valor = cadenaArreglo [i];
			int indice = Integer.parseInt(valor)%7; // depende el tamaño cambia el indice
			int intento = 1;
			
			System.out.println("El indice es  " + indice + "  Para el valor "+ valor);
			
			while (arreglo [indice]!= "-1") {
				if (Cuadratico) { // en caso de colision, funcion cuadratica
	                indice = (indice + intento ^ 2) % tamano;
	               indice++;
	               intento++;
	                System.out.println("Ocurrrio una colision en el indice " + (indice - 1) + ", cambiar al indice " + indice);
	                
				}else { // si no, en caso de colison, funcion lineal
					indice ++; 
				
				System.out.println("Ocurrrio una colision en el indice " + (indice -1) + ", cambiar al indice " + indice);
				}

				indice%= tamano;
			}
			arreglo [indice] = valor;
		}
	}
	
	public void limpiarTabla() {
	    Arrays.fill(arreglo, "-1");
	}
	
	public void mostrarTabla() {
		
		int incremento=0;
		int i;
		int j;
		
		for(i=0;i<1;i++) {
			
			incremento+=8;
			
			for(j=0;j<71;j++) {
				System.out.print("-");
			}
		System.out.println();
		
		for(j=incremento -8;j<incremento;j++) {
			
		System.out.format("|%3s"+"",j);	
		}
		
		System.out.println("|");
		for(int n=0;n<71;n++) {
			
		System.out.print("-");	
		}
		
		System.out.println();
		for(j=incremento -8;j<incremento;j++) {
			
			if(arreglo[j].equals("-1")) {
				System.out.print("|");
				
				}else {
					System.out.print(String.format("|%3s"+"", arreglo[j]));
				}
			}
		System.out.println("|");
		for(j=0;j<71;j++) {
			System.out.print("-");
		}
		System.out.println();

		}
	}
	
	public String buscar (String valor) {
		int indice = Integer.parseInt(valor)%7;
		
		while (arreglo [indice]!= "-1") {
			if (arreglo [indice] == valor) {
				System.out.println("El valor fue encontrado en el indice  " + indice);
				return arreglo [indice];
			}
			
			indice ++;
			indice%= tamano;
			contador ++;
			
			if(contador>7) {
				break;
			}
		}
		return null;

	}
}
