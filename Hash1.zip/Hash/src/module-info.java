/**
 * 
 */
/**
 * @author floresco.co
 *
 */
module Hash {
}